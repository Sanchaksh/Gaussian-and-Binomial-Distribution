from setuptools import setup

setup(name='pyprobability',
      version='1.0',
      description='Gaussian and Binomial distributions',
      author= 'Sanchaksh Kaul',
      packages=['pyprobability'],
      author_email= 'sanchakshkaul@gmail.com',
      zip_safe=False)
